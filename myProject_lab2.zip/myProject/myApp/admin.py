from django.contrib import admin
from myApp.models import *

# Register your models here.
admin.site.register(Team)
admin.site.register(Player)
admin.site.register(Game)
admin.site.register(Stat)